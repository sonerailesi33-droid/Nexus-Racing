# Sinyal AI - derleme
Android Studio: klasörü aç > Gradle sync > Build > Build APK(s) > app/build/outputs/apk/debug/app-debug.apk
GitHub Actions: projeyi GitHub'a it > Actions > Build APK > artifact'ı indir.
Kurulum sonrası: Ayarlar'da Groq anahtarını gir; Qwen 0.6B .task dosyasını seç (Hugging Face litert-community Qwen3-0.6B); varsayılan asistanı ve erişilebilirliği aç.
