package ai.sinyal
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class Call(val id: String, val name: String, val args: JSONObject)
data class Msg(val role: String, val text: String = "", val calls: List<Call> = emptyList(), val callId: String = "")
data class Reply(val text: String, val calls: List<Call>)
interface Engine { suspend fun chat(msgs: List<Msg>, tools: List<Tool>): Reply }

class GroqEngine(private val key: String) : Engine {
    private val http = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
    override suspend fun chat(msgs: List<Msg>, tools: List<Tool>): Reply = withContext(Dispatchers.IO) {
        val m = JSONArray()
        msgs.forEach { x ->
            val o = JSONObject().put("role", x.role)
            when {
                x.role == "tool" -> o.put("tool_call_id", x.callId).put("content", x.text)
                x.calls.isNotEmpty() -> {
                    o.put("content", JSONObject.NULL)
                    o.put("tool_calls", JSONArray(x.calls.map {
                        JSONObject().put("id", it.id).put("type", "function")
                            .put("function", JSONObject().put("name", it.name).put("arguments", it.args.toString()))
                    }))
                }
                else -> o.put("content", x.text)
            }
            m.put(o)
        }
        val t = JSONArray(tools.map {
            JSONObject().put("type", "function").put("function",
                JSONObject().put("name", it.name).put("description", it.desc).put("parameters", JSONObject(it.params)))
        })
        val body = JSONObject().put("model", "openai/gpt-oss-20b").put("messages", m).put("tools", t).toString()
        val req = Request.Builder().url("https://api.groq.com/openai/v1/chat/completions").header("Authorization", "Bearer $key")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) error("Groq ${r.code}: ${s.take(200)}")
            val msg = JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
            val tc = msg.optJSONArray("tool_calls")
            Reply(msg.optString("content", ""), if (tc == null) emptyList() else List(tc.length()) {
                val f = tc.getJSONObject(it); val fn = f.getJSONObject("function")
                Call(f.getString("id"), fn.getString("name"), JSONObject(fn.optString("arguments", "{}").ifBlank { "{}" }))
            })
        }
    }
}

/** Qwen 0.6B (MediaPipe .task modeli) tamamen cihazda çalışır. Araç çağrısı JSON metin protokolüyle. */
class LocalEngine(private val c: Context) : Engine {
    companion object {
        fun modelFile(c: Context) = File(c.filesDir, "qwen.task")
        private var llm: LlmInference? = null
    }
    override suspend fun chat(msgs: List<Msg>, tools: List<Tool>): Reply = withContext(Dispatchers.Default) {
        val f = modelFile(c)
        if (!f.exists()) error("Yerel model yüklenmemiş. Ayarlar'dan Qwen .task dosyasını seç.")
        if (llm == null) llm = LlmInference.createFromOptions(c,
            LlmInference.LlmInferenceOptions.builder().setModelPath(f.path).setMaxTokens(1024).build())
        val sys = "Sen Sinyal AI'sın, kısa Türkçe cevap ver. Araç gerekirse SADECE şu JSON ile cevap ver: {\"tool\":\"ad\",\"args\":{...}}. Araçlar:\n" +
            tools.joinToString("\n") { "- ${it.name}: ${it.desc} parametreler=${it.params}" }
        val sb = StringBuilder("<|im_start|>system\n$sys<|im_end|>\n")
        msgs.filter { it.role != "system" }.forEach { x ->
            when {
                x.role == "tool" -> sb.append("<|im_start|>user\n[araç sonucu] ${x.text}<|im_end|>\n")
                x.calls.isNotEmpty() -> sb.append("<|im_start|>assistant\n{\"tool\":\"${x.calls[0].name}\",\"args\":${x.calls[0].args}}<|im_end|>\n")
                else -> sb.append("<|im_start|>${x.role}\n${x.text}<|im_end|>\n")
            }
        }
        sb.append("<|im_start|>assistant\n<think>\n\n</think>\n\n")
        val out = llm!!.generateResponse(sb.toString()).replace(Regex("<think>.*?</think>", RegexOption.DOT_MATCHES_ALL), "").trim()
        val j = Regex("\\{.*\\}", RegexOption.DOT_MATCHES_ALL).find(out)?.value
        val call = try { j?.let { JSONObject(it) }?.takeIf { it.has("tool") } } catch (e: Exception) { null }
        if (call != null) Reply("", listOf(Call("local${System.nanoTime()}", call.getString("tool"), call.optJSONObject("args") ?: JSONObject())))
        else Reply(out, emptyList())
    }
}

class Agent(private val c: Context, private val store: Store) {
    private val tools = Tools(c)
    private fun online(): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }
    private fun engine(): Pair<Engine, String> {
        val cloud = store.mode == "cloud" || (store.mode == "auto" && online())
        return if (cloud && store.groqKey.isNotBlank()) GroqEngine(store.groqKey) to "Groq" else LocalEngine(c) to "Local"
    }
    suspend fun ask(history: List<Pair<String, String>>): Pair<String, String> {
        val (e, label) = engine()
        val mem = store.memories().joinToString("; ")
        val msgs = mutableListOf(Msg("system", "Sen Sinyal AI'sın, Android asistanısın. Türkçe, kısa yanıt ver. Telefon işlemleri için araçları kullan. Kullanıcı hakkında bilinenler: $mem"))
        history.takeLast(12).forEach { msgs += Msg(it.first, it.second) }
        repeat(4) {
            val r = e.chat(msgs, tools.list)
            if (r.calls.isEmpty()) return r.text.ifBlank { "Tamam." } to label
            msgs += Msg("assistant", calls = r.calls)
            r.calls.forEach { msgs += Msg("tool", tools.run(it.name, it.args), callId = it.id) }
        }
        return "İşlem tamamlandı." to label
    }
}
