package ai.sinyal
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.service.voice.*
import android.view.accessibility.AccessibilityEvent

class AssistService : VoiceInteractionService()
class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?) = object : VoiceInteractionSession(this) {
        override fun onShow(a: Bundle?, f: Int) {
            startAssistantActivity(Intent(this@AssistSessionService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("voice", true))
            hide()
        }
    }
}
class SignalAccessibility : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    companion object { var instance: SignalAccessibility? = null }
}
