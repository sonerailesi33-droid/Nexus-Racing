package ai.sinyal
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tts = TextToSpeech(this) { tts?.language = Locale("tr", "TR") }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF4CC9F0), background = Color(0xFF0B0F17), surface = Color(0xFF151B27))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Chat() }
            }
        }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable fun Chat() {
        val ctx = LocalContext.current
        val store = remember { Store(ctx) }; val agent = remember { Agent(ctx, store) }
        val scope = rememberCoroutineScope()
        val msgs = remember { mutableStateListOf<Pair<String, String>>().apply { addAll(store.history()) } }
        var input by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
        var settings by remember { mutableStateOf(false) }
        var key by remember { mutableStateOf(store.groqKey) }; var mode by remember { mutableStateOf(store.mode) }

        fun send(t: String) {
            if (t.isBlank() || busy) return
            msgs += "user" to t; input = ""; busy = true
            scope.launch {
                val a = try { agent.ask(msgs.toList()).first } catch (e: Exception) { "Hata: ${e.message}" }
                msgs += "assistant" to a; store.saveHistory(msgs); busy = false
                if (store.speak) tts?.speak(a, TextToSpeech.QUEUE_FLUSH, null, "r")
            }
        }
        val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
        }
        val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR"))
        }
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
            u?.let { scope.launch(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(it)?.use { i -> LocalEngine.modelFile(ctx).outputStream().use { o -> i.copyTo(o) } }
            } }
        }
        LaunchedEffect(Unit) { if (intent?.getBooleanExtra("voice", false) == true) perm.launch(Manifest.permission.RECORD_AUDIO) }

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Sinyal AI", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { settings = !settings }) { Text(if (settings) "Sohbet" else "Ayarlar") }
            }
            if (settings) Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(key, { key = it; store.groqKey = it }, label = { Text("Groq API anahtarı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto" to "Otomatik", "cloud" to "Groq", "local" to "Yerel").forEach { (k, l) ->
                        FilterChip(mode == k, { mode = k; store.mode = k }, { Text(l) })
                    }
                }
                Button(onClick = { pick.launch(arrayOf("*/*")) }) { Text("Qwen 0.6B model dosyasını seç (.task)") }
                Button(onClick = { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }) { Text("Varsayılan asistan olarak ayarla") }
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Erişilebilirliği aç (ekran görüntüsü)") }
                Button(onClick = { msgs.clear(); store.clearHistory() }) { Text("Geçmişi temizle") }
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(msgs) { (r, t) ->
                        Box(Modifier.fillMaxWidth(), contentAlignment = if (r == "user") Alignment.CenterEnd else Alignment.CenterStart) {
                            Text(t, Modifier.background(if (r == "user") Color(0xFF1B4965) else Color(0xFF151B27), RoundedCornerShape(14.dp)).padding(12.dp))
                        }
                    }
                    if (busy) item { Text("Düşünüyor…", color = Color.Gray) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Bir şey söyle…") })
                    TextButton(onClick = { perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("🎤") }
                    Button(onClick = { send(input) }) { Text("Gönder") }
                }
            }
        }
    }
}
