package ai.sinyal
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class Store(c: Context) {
    private val secure = EncryptedSharedPreferences.create(c, "secure", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    private val p = c.getSharedPreferences("data", Context.MODE_PRIVATE)
    var groqKey: String
        get() = secure.getString("groq", "") ?: ""
        set(v) { secure.edit().putString("groq", v).apply() }
    var mode: String
        get() = p.getString("mode", "auto")!!
        set(v) { p.edit().putString("mode", v).apply() }
    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) { p.edit().putBoolean("speak", v).apply() }
    fun memories(): List<String> = JSONArray(p.getString("mem", "[]")).let { a -> List(a.length()) { a.getString(it) } }
    fun addMemory(f: String) { val a = JSONArray(p.getString("mem", "[]")); a.put(f); p.edit().putString("mem", a.toString()).apply() }
    fun history(): List<Pair<String, String>> = JSONArray(p.getString("hist", "[]")).let { a -> List(a.length()) { a.getJSONObject(it).let { o -> o.getString("r") to o.getString("t") } } }
    fun saveHistory(h: List<Pair<String, String>>) {
        val a = JSONArray(); h.takeLast(200).forEach { a.put(JSONObject().put("r", it.first).put("t", it.second)) }
        p.edit().putString("hist", a.toString()).apply()
    }
    fun clearHistory() { p.edit().remove("hist").apply() }
}
