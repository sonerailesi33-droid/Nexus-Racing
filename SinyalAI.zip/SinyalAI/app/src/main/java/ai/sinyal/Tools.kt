package ai.sinyal
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import org.json.JSONObject

data class Tool(val name: String, val desc: String, val params: String)
class Tools(private val c: Context) {
    val list = listOf(
        Tool("open_app", "Telefondaki bir uygulamayı adıyla açar", """{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}"""),
        Tool("flashlight", "Feneri açar veya kapatır", """{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}"""),
        Tool("set_volume", "Medya ses seviyesini 0-100 yüzde olarak ayarlar", """{"type":"object","properties":{"percent":{"type":"integer"}},"required":["percent"]}"""),
        Tool("screenshot", "Ekran görüntüsü alır", """{"type":"object","properties":{}}"""),
        Tool("remember", "Kullanıcı hakkında kalıcı bir bilgiyi yerel hafızaya kaydeder", """{"type":"object","properties":{"fact":{"type":"string"}},"required":["fact"]}""")
    )
    fun run(name: String, a: JSONObject): String = try {
        when (name) {
            "open_app" -> {
                val pm = c.packageManager
                val q = a.getString("name").lowercase()
                val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                if (app == null) "Uygulama bulunamadı: $q" else {
                    c.startActivity(pm.getLaunchIntentForPackage(app.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Açıldı: ${app.loadLabel(pm)}"
                }
            }
            "flashlight" -> {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, a.getBoolean("on")); "Fener ${if (a.getBoolean("on")) "açıldı" else "kapandı"}"
            }
            "set_volume" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val p = a.getInt("percent").coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * p / 100, AudioManager.FLAG_SHOW_UI); "Ses %$p yapıldı"
            }
            "screenshot" -> {
                val s = SignalAccessibility.instance
                if (s == null) "Erişilebilirlik servisi kapalı. Ayarlar > Erişilebilirlik > Sinyal AI'yı aç."
                else { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); "Ekran görüntüsü alındı" }
            }
            "remember" -> { Store(c).addMemory(a.getString("fact")); "Kaydedildi" }
            else -> "Bilinmeyen araç: $name"
        }
    } catch (e: Exception) { "Hata: ${e.message}" }
}
